function test(){
    console.log("test");
}
test();