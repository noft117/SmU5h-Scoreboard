package com.scoreboard;


import org.apache.commons.io.FileUtils;
import java.awt.Color;

import java.awt.Font;
import java.awt.FontMetrics;

import java.awt.Graphics;
import java.awt.Graphics2D;

import java.awt.image.BufferedImage;


import javax.imageio.ImageIO;

import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import java.io.*;  
public class Paint extends JPanel {
    private Graphics2D g2D;

    public Paint() {
    }

    private void getInfoPanel(Graphics2D g2D, int player1Score, int player2Score, String player1Name,
            String player2Name) {
        int rowY = 92;
        paintText(g2D, String.valueOf(player1Name), Color.WHITE, 52,
                630, rowY);
        paintText(g2D, String.valueOf(player1Score), Color.BLACK, 60,
                920, rowY);

        paintText(g2D, String.valueOf(player2Score), Color.BLACK, 60,
                1005, rowY);

        paintText(g2D, String.valueOf(player2Name), Color.WHITE, 52,
                1280, rowY);

    }

    private void paintText(Graphics2D g2D, String str, Color color, int size, int x, int y) {
        g2D.setPaint(color);
        FontMetrics myMetrics = getFontMetrics(new Font("Bebas Neue", Font.BOLD,
                size));
        int width = SwingUtilities.computeStringWidth(myMetrics, str);
        int widthOfPanel = 500;
        myMetrics = getFontMetrics(new Font("Bebas Neue", Font.BOLD, size));
        width = SwingUtilities.computeStringWidth(myMetrics, str);
        int amtToMove = 0;
        if (width >= widthOfPanel - 50) {

            size -= 10;

            width = widthOfPanel;
            amtToMove = -40;
        }

        x -= (width / 2) + amtToMove;

        g2D.setFont(new Font("Bebas Neue", Font.BOLD, size));
        String str2 = str.substring(0, Math.min(str.length(), 23));
        if ((str2.length() - 3) >= 20) {

            str2 += "...";

        }
        g2D.drawString(str2, x, y);

    }

    // save top 8 graphic
    public void saveGraphics(Graphics g, BufferedImage bi, int player1Score, int player2Score, String player1Name,String player2Name,String player1Sponsor,
    String player2Sponsor,String gameName,String eventName,String roundName,int bestOf
            ) {

        //this.g2D = (Graphics2D) g;

        /* getInfoPanel(g2D, player1Score, player2Score, player1Name,
                player2Name); */

        /* try {
            ImageIO.write(bi, "PNG", new File("image.PNG"));

            System.out.println("Done Saving graphic as PNG!");
        } catch (IOException e) {

            e.printStackTrace();
        } */
        File htmlTemplateFile = new File("template.html");
        String htmlString = "";
        try {
            htmlString = FileUtils.readFileToString(htmlTemplateFile);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        
        
        htmlString = htmlString.replace("$p1Name", player1Name);
        htmlString = htmlString.replace("$p1Sponsor", player1Sponsor);
        htmlString = htmlString.replace("$p1Score", String.valueOf(player1Score));
        htmlString = htmlString.replace("$p2Name", player2Name);
        htmlString = htmlString.replace("$p2Sponsor", player2Sponsor);
        htmlString = htmlString.replace("$p2Score", String.valueOf(player2Score));
        htmlString = htmlString.replace("$eventName", String.valueOf(eventName));
        htmlString = htmlString.replace("$gameName", String.valueOf(gameName));
        htmlString = htmlString.replace("$roundName", String.valueOf(roundName));
        htmlString = htmlString.replace("$bestOf", String.valueOf(bestOf));


        //htmlString = htmlString.replace("$update", "<meta http-equiv=\"refresh\" content=\"5\"; url=\"output.html\">");
 
        File newHtmlFile = new File("output.html");
        try {
            FileUtils.writeStringToFile(newHtmlFile, htmlString);
            System.out.println("done writing html output.html");
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}