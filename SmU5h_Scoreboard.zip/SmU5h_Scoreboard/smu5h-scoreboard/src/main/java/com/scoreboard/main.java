package com.scoreboard;


import java.awt.*;
import javax.swing.*;
import javax.swing.plaf.nimbus.NimbusLookAndFeel;

//import Paint;

import java.io.PrintWriter;

import java.io.FileReader;
import java.io.BufferedReader;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;

/**
 * Keep track of scores between two players and output to .txt file and .png on save so the .txt file or .png
 * can be imported to an app like Open Broadcast Software and display player scores to a recording or live stream.
 * Inspired by other scoreboard assistant tools.
 *
 * @author noft
 * @version 4/17/2024
 */
public class main extends JFrame
{
    
    // instance variables - replace the example below with your own
    private static JFrame f;
    //private static Time lastUpdated;
    private static JLabel gameNameLabel,eventNameLabel,roundNameLabel,bestOfLabel;
    private static JButton btnResetScore,
    btnSave,
    btnSwap,
    btnReset;  
    private static JSpinner spPlayer1,
    spPlayer2,spBestOf; 
    private static int player1Score=0,
    player2Score=0;
    private static JLabel player1NameLabel,player2NameLabel,player1ScoreLabel,player2ScoreLabel,player1SponsorLabel,player2SponsorLabel;
    private static String player1Name="",player1Sponsor="",
    player2Name="",
    player2Sponsor="";
    private static String eventName,roundName,gameName;
    private static int bestOf;
    private static BufferedImage bi;
    private static Graphics2D g;
    private static BufferedReader reader;
    private static BufferedImage image;
    private static Paint paint;
    static JTextField tbxPlayer1Name;
    static JTextField tbxPlayer1Sponsor;
    static JTextField tbxPlayer2Name;
    static JTextField tbxPlayer2Sponsor;

    static JTextField tbxEventName;
    static JTextField tbxRoundName;
    static JTextField tbxGameName;
    static JTextField tbxBestOf;

    private static JLabel lp1,lp2;
    /**
     * Constructor for objects of class example
     */
    
    public static void main(String[] args)
    {
        bi = new BufferedImage(1920, 1080, BufferedImage.TYPE_INT_ARGB);
        g = bi.createGraphics();
        load();
        paint = new Paint();
        f = new JFrame("SmU5h Scoreboard");
        try {
            UIManager.setLookAndFeel(new NimbusLookAndFeel());
            UIManager.put("control", new Color(128, 128, 128));
            UIManager.put("info", new Color(128, 128, 128));
            UIManager.put("nimbusBase", new Color(18, 30, 49));
            UIManager.put("nimbusAlertYellow", new Color(248, 187, 0));
            UIManager.put("nimbusDisabledText", new Color(128, 128, 128));
            UIManager.put("nimbusFocus", new Color(115, 164, 209));
            UIManager.put("nimbusGreen", new Color(176, 179, 50));
            UIManager.put("nimbusInfoBlue", new Color(66, 139, 221));
            UIManager.put("nimbusLightBackground", new Color(18, 30, 49));
            UIManager.put("nimbusOrange", new Color(191, 98, 4));
            UIManager.put("nimbusRed", new Color(169, 46, 34));
            UIManager.put("nimbusSelectedText", new Color(255, 255, 255));
            UIManager.put("nimbusSelectionBackground", new Color(104, 93, 156));
            UIManager.put("text", new Color(230, 230, 230));
            SwingUtilities.updateComponentTreeUI(f);
        } catch (UnsupportedLookAndFeelException exc) {
            System.err.println("Nimbus: Unsupported Look and feel!");
        }
        // load vs image
        Image scaledImage = null;
        ImageIcon icon = null;
        try {                
            image = ImageIO.read(new File("vsIcon.png"));
            scaledImage = image.getScaledInstance(-1, 35, Image.SCALE_SMOOTH);
            
        } catch (IOException ex) {
            ex.printStackTrace();
            System.out.println("something went wrong");
        }
        icon = new ImageIcon(scaledImage);
        JLabel lblVsIcon = new JLabel(icon);



        
        // buttons
        // buttons that we will use for using commands
        btnReset = new JButton("reset");
        btnResetScore = new JButton("reset scores");
        btnSave = new JButton("save");
        btnSwap = new JButton("swap");

        // text fields
        // text fields for the player names
        tbxPlayer1Name = new JTextField(4);
        tbxPlayer1Name.setText(player1Name);
        tbxPlayer1Sponsor = new JTextField(4);
        tbxPlayer1Sponsor.setText(player1Sponsor);
        tbxPlayer2Name = new JTextField(4);
        tbxPlayer2Name.setText(player2Name);
        tbxPlayer2Sponsor = new JTextField(4);
        tbxPlayer2Sponsor.setText(player2Sponsor);


        tbxEventName = new JTextField(4);
        tbxEventName.setText(eventName);
        tbxGameName = new JTextField(4);
        tbxGameName.setText(gameName);
        tbxRoundName = new JTextField(4);
        tbxRoundName.setText(roundName);
        tbxBestOf = new JTextField(3);
        tbxBestOf.setText(String.valueOf(bestOf));


        // panels
        // create new container panels so we can organize them 
        JPanel pMain = new JPanel(); 

        JPanel pPlayer1 = new JPanel(); // container for player
        JPanel pPlayer1Info = new JPanel(); // contains name and swinger

        JPanel pPlayer2 = new JPanel(); // container for player 2
        JPanel pPlayer2Info = new JPanel(); // contains name and swinger

        JPanel pVs = new JPanel(); // contains for VS image
        JPanel pPlayers = new JPanel();  // container for both players

        JPanel pControls = new JPanel(); // container for controls
        JPanel pControlsBottom = new JPanel(); // container for main buttons
        JPanel pControlsTop = new JPanel(); // container for swap button
        JPanel pExtraControls = new JPanel();
        
        // panel text box player 1
        //tbxPlayer1Name.setPreferredSize(new Dimension(75,30)); // increase the size of the textbox
        //tbxPlayer1Sponsor.setPreferredSize(new Dimension(75,30)); // increase the size of the textbox
        //tbxPlayer2Sponsor.setPreferredSize(new Dimension(75,30)); // increase the size of the textbox

        //tbxGameName.setPreferredSize(new Dimension(75,30)); // increase the size of the textbox
        //tbxRoundName.setPreferredSize(new Dimension(75,30)); // increase the size of the textbox
        //tbxBestOf.setPreferredSize(new Dimension(75,30)); // increase the size of the textbox
        //tbxEventName.setPreferredSize(new Dimension(75,30)); // increase the size of the textbox

        gameNameLabel = new JLabel("Game: ");
        roundNameLabel = new JLabel("Round: ");
        eventNameLabel = new JLabel("Event: ");
        bestOfLabel = new JLabel("Best of: ");

        JLabel lp1 = new JLabel("Player 1");
        JLabel lp2 = new JLabel("Player 2");
       
        
       
        JPanel pGame = new JPanel();
        JPanel pEvent = new JPanel();
        JPanel pRound = new JPanel();
        JPanel pBestOf = new JPanel();
        pEvent.add(eventNameLabel);
        pEvent.add(tbxEventName);
        pEvent.setLayout(new BoxLayout(pEvent, BoxLayout.Y_AXIS));
        pExtraControls.add(pEvent);

        pGame.add(gameNameLabel);
        pGame.add(tbxGameName);
        pGame.setLayout(new BoxLayout(pGame, BoxLayout.Y_AXIS));
        pExtraControls.add(pGame);

        pRound.add(roundNameLabel);
        pRound.add(tbxRoundName);
        pRound.setLayout(new BoxLayout(pRound, BoxLayout.Y_AXIS));
        pExtraControls.add(pRound);

        //pExtraControls.setLayout(new FlowLayout(FlowLayout.RIGHT));
        //pExtraControls.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
        spBestOf= new JSpinner(new SpinnerNumberModel(3, 3, 5, 2)); // player 1 score spinner. used to tick up or down the score or user can type it in
     
        spBestOf.setFont(new Font("SANS_SERIF", Font.PLAIN,16)); // make the font larger
        spBestOf.setValue(bestOf); // sets the value to the stored player 1 score
        //spBestOf.setPreferredSize(new Dimension(50,30)); // increase the size of the spinner

        pBestOf.add(bestOfLabel);
        pBestOf.add(spBestOf);
        pBestOf.setLayout(new BoxLayout(pBestOf, BoxLayout.Y_AXIS));
        pExtraControls.add(pBestOf);
        



        player1NameLabel=new JLabel("Name: ");
        player2NameLabel=new JLabel("Name: ");
        player2SponsorLabel=new JLabel("Sponsor: ");
        player1SponsorLabel=new JLabel("Sponsor: ");
        player1ScoreLabel = new JLabel("Score: ");
        player2ScoreLabel = new JLabel("Score: ");

        JPanel pName1 = new JPanel();
        JPanel pName2 = new JPanel();
        JPanel pSponsor1 = new JPanel();
        JPanel pSponsor2 = new JPanel();
        JPanel pScore1 = new JPanel();
        JPanel pScore2 = new JPanel();

        pSponsor1.add(player1SponsorLabel);
        pSponsor1.add(tbxPlayer1Sponsor); // add player 2 name to player 2 info container
        pSponsor1.setLayout(new BoxLayout(pSponsor1, BoxLayout.Y_AXIS));

        pName1.add(player1NameLabel);
        pName1.add(tbxPlayer1Name); // add player 2 name to player 2 info container
        pName1.setLayout(new BoxLayout(pName1, BoxLayout.Y_AXIS));

        // panel spinner player 1
        

        spPlayer1= new JSpinner(new SpinnerNumberModel(0, 0, 5, 1)); // player 1 score spinner. used to tick up or down the score or user can type it in
        spPlayer1.setFont(new Font("SANS_SERIF", Font.PLAIN,16)); // make the font larger
        spPlayer1.setValue(player1Score); // sets the value to the stored player 1 score
        //spPlayer1.setPreferredSize(new Dimension(50,30)); // increase the size of the spinner


        pScore1.add(player1ScoreLabel);
        pScore1.add(spPlayer1); // add spinner to player 1 info panel
        pScore1.setLayout(new BoxLayout(pScore1, BoxLayout.Y_AXIS));

        pPlayer1Info.add(pName1); // add player 2 name to player 2 info container
        pPlayer1Info.add(pSponsor1); // add player 2 name to player 2 info container
        pPlayer1Info.add(pScore1); // add player 2 name to player 2 info container
       
        pPlayer1.add(pPlayer1Info); // add player 1 info to player 1 container
        //pPlayer1.setBorder(BorderFactory.createLineBorder(Color.black));
        // panel spinner player 2
        spPlayer2= new JSpinner(new SpinnerNumberModel(0, 0, 5, 1)); // player 2 score spinner. used to tick up or down the score or user can type it in
    
        spPlayer2.setFont(new Font("SANS_SERIF", Font.PLAIN,16)); // make the font larger
        spPlayer2.setValue(player2Score); // sets the value to the stored player 2 score
        //spPlayer2.setPreferredSize(new Dimension(50,30)); // increase the size of the spinner
        pScore2.add(player2ScoreLabel);
        pScore2.add(spPlayer2); // add spinner to player 2 info panel
        pScore2.setLayout(new BoxLayout(pScore2, BoxLayout.Y_AXIS));
        
        // panel text box player 2
        tbxPlayer2Name.setPreferredSize(new Dimension(75,30));  // increase the size of the textbox
        pName2.add(player2NameLabel);
        pName2.setLayout(new BoxLayout(pName2, BoxLayout.Y_AXIS));

        pName2.add(tbxPlayer2Name); // add player 2 name to player 2 info container
        pSponsor2.add(player2SponsorLabel);

        pSponsor2.add(tbxPlayer2Sponsor); // add player 2 name to player 2 info container
        pSponsor2.setLayout(new BoxLayout(pSponsor2, BoxLayout.Y_AXIS));
       
        pPlayer2.add(pSponsor2); // add player 2 info to player 2 container
        pPlayer2.add(pName2); // add player 2 info to player 2 container
        pPlayer2.add(pScore2); // add player 2 info to player 2 container
        pPlayer2.add(pPlayer2Info); // add player 2 info to player 2 container
        //pPlayer2.setBorder(BorderFactory.createLineBorder(Color.black));
        pVs.add(lblVsIcon); // add vs icon image to vs container

        JPanel pp1 = new JPanel();
        JPanel pp2 = new JPanel();
        pp1.add(lp1);
    
        pp1.add(pPlayer1);
        //pp1.setLayout(new BoxLayout(pp1, BoxLayout.Y_AXIS));
        //pp1.setLayout(new FlowLayout(FlowLayout.LEFT));

        pPlayers.add(pp1); // add player 1 container to players container
        //pPlayer1.setLayout(new FlowLayout(FlowLayout.RIGHT));
  

        pPlayers.add(pVs);// add vs container to players container
        pp2.add(pPlayer2);
        pp2.add(lp2);
  
       
        //pp2.setLayout(new BoxLayout(pp2, BoxLayout.Y_AXIS));
    
        pPlayers.add(pp2); // add player 2 container to players container
        //pPlayer2.setLayout(new FlowLayout(FlowLayout.LEFT));
        
        pMain.add(pPlayers); // add players containers to main container

        // Panel Buttons - add buttons to button containers
        pControlsBottom.add(btnSwap);

        pControlsTop.add(btnReset);
        pControlsTop.add(btnResetScore);
        pControlsBottom.add(btnSave);
        pControls.add(pExtraControls);
        pControls.add(pControlsTop);
        pControls.add(pControlsBottom);


        pPlayer1.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
        pPlayer2.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
        //pControls.setLayout(new FlowLayout(FlowLayout.LEFT));
        //pControlsTop.setLayout(new FlowLayout(FlowLayout.LEFT));
        //pControlsBottom.setLayout(new FlowLayout(FlowLayout.LEFT));
        //pControls.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
        pMain.add(pControls); // add buttons to main container
        pMain.setLayout(new BoxLayout(pMain, BoxLayout.Y_AXIS));
        f.add(pMain); // add main container to frame

        //f.setSize(500,165); // sets the size of the frame
        //f.setResizable(false); // sets it so user cant change the frame size
        //Dimension dim = Toolkit.getDefaultToolkit().getScreenSize(); // gets the device screen size
        f.setLocationRelativeTo(null); // centers the frame
        //f.setLocation(dim.width/2-f.getSize().width/2, dim.height/2-f.getSize().height/2); // centers the frame
        f.getRootPane().setDefaultButton(btnSave); // sets default button to save so user can press enter and save
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        f.pack();
        f.setVisible(true);

        btnSwap.addActionListener(e -> swap(spPlayer1,spPlayer2,tbxPlayer1Name,tbxPlayer2Name,tbxPlayer1Sponsor,tbxPlayer2Sponsor)); // swap action
        btnResetScore.addActionListener(e -> resetScores(spPlayer1,spPlayer2)); // reset score action
        btnReset.addActionListener(e -> reset(spPlayer1,spPlayer2,tbxPlayer1Name,tbxPlayer2Name,tbxPlayer1Sponsor,tbxPlayer2Sponsor,tbxEventName,tbxGameName,tbxRoundName,spBestOf)); // reset action
        btnSave.addActionListener(e -> save(spPlayer1,spPlayer2,tbxPlayer1Name,tbxPlayer2Name,tbxPlayer1Sponsor,tbxPlayer2Sponsor,tbxEventName,tbxGameName,tbxRoundName,spBestOf)); // save action
    }

    // load any data from the txt files
    private static void load(){
        try
        {
            reader = new BufferedReader(new FileReader("player1Score.txt"));
            String line = reader.readLine();
            player1Score=Integer.parseInt(line);
            reader.close();
        }
        catch (Exception e)
        {
            player1Score=0;
        } 

        try
        {
            reader = new BufferedReader(new FileReader("player1Name.txt"));
            String line = reader.readLine();
            player1Name=line;
            reader.close();
        }
        catch (Exception e)
        {
            player1Name="Player 1";
        } 
        try
        {
            reader = new BufferedReader(new FileReader("player1Sponsor.txt"));
            String line = reader.readLine();
            player1Sponsor=line;
            reader.close();
        }
        catch (Exception e)
        {
            player1Sponsor="sponsor";
        } 
        try
        {
            reader = new BufferedReader(new FileReader("player2Score.txt"));
            String line = reader.readLine();
            player2Score=Integer.parseInt(line);
            reader.close();
        }
        catch (Exception e)
        {
            player2Score=0;
        } 

        try
        {
            reader = new BufferedReader(new FileReader("player2Name.txt"));
            String line = reader.readLine();
            player2Name=line;
            reader.close();
        }
        catch (Exception e)
        {
            player2Name="Player 2";
        } 
        try
        {
            reader = new BufferedReader(new FileReader("player2Sponsor.txt"));
            String line = reader.readLine();
            player2Sponsor=line;
            reader.close();
        }
        catch (Exception e)
        {
            player2Sponsor="sponsor 2";
        } 
        try
        {
            reader = new BufferedReader(new FileReader("gameName.txt"));
            String line = reader.readLine();
            gameName=line;
            reader.close();
        }
        catch (Exception e)
        {
            gameName="game";
        } 
        try
        {
            reader = new BufferedReader(new FileReader("eventName.txt"));
            String line = reader.readLine();
            eventName=line;
            reader.close();
        }
        catch (Exception e)
        {
            eventName="event";
        } 
        try
        {
            reader = new BufferedReader(new FileReader("roundName.txt"));
            String line = reader.readLine();
            roundName=line;
            reader.close();
        }
        catch (Exception e)
        {
            roundName="round";
        } 
        try
        {
            reader = new BufferedReader(new FileReader("bestOf.txt"));
            String line = reader.readLine();
            bestOf=Integer.parseInt(line);
            reader.close();
        }
        catch (Exception e)
        {
            bestOf=3;
        } 
    }
    // swap player 1 info with player 2 info
    private static void swap(JSpinner s, JSpinner s1,JTextField t,JTextField t1,JTextField ts1,JTextField ts2)
    {
        int p1Score = Integer.parseInt(s1.getValue().toString());
        int p2Score= Integer.parseInt(s.getValue().toString());

        String str =t.getText();
        String str1=t1.getText();

        String strs1 = ts1.getText();
        String strs2 = ts2.getText();

        t.setText(str1);
        t1.setText(str);

        s.setValue(p1Score);

        s1.setValue(p2Score);

        ts1.setText(strs2);
        ts2.setText(strs1);
    }
    // save to txt files
    private static void save(JSpinner s,JSpinner s1,JTextField t,JTextField t1,JTextField ts1,JTextField ts2,JTextField ten,JTextField tgn,JTextField trn,JSpinner bo){
        player1Score = Integer.parseInt(s.getValue().toString());
        player2Score = Integer.parseInt(s1.getValue().toString());
        player1Name = t.getText();
        player1Sponsor = ts1.getText();
        
        player2Name = t1.getText();
        player2Sponsor = ts2.getText();
        gameName=tgn.getText();
        eventName=ten.getText();
        roundName=trn.getText();
        bestOf=Integer.parseInt(bo.getValue().toString());
        try{
            PrintWriter writer = new PrintWriter("player1Score.txt", "UTF-8");

            writer.print(player1Score);
            writer.close();
        }catch(Exception e){
            e.printStackTrace();
        }
        try{
            PrintWriter writer = new PrintWriter("player1Name.txt", "UTF-8");

            writer.print(player1Name);
            writer.close();
        }catch(Exception e){
            e.printStackTrace();
        }
        try{
            PrintWriter writer = new PrintWriter("player1Sponsor.txt", "UTF-8");

            writer.print(player1Sponsor);
            writer.close();
        }catch(Exception e){
            e.printStackTrace();
        }
        try{
            PrintWriter writer = new PrintWriter("player2Score.txt", "UTF-8");
            writer.print(player2Score);
            writer.close();
        }catch(Exception e){
            e.printStackTrace();
        }
        try{
            PrintWriter writer = new PrintWriter("player2Name.txt", "UTF-8");

            writer.print(player2Name);
            writer.close();
        }catch(Exception e){
            e.printStackTrace();
        }
        try{
            PrintWriter writer = new PrintWriter("player2Sponsor.txt", "UTF-8");

            writer.print(player2Sponsor);
            writer.close();
        }catch(Exception e){
            e.printStackTrace();
        }
        try{
            PrintWriter writer = new PrintWriter("gameName.txt", "UTF-8");

            writer.print(gameName);
            writer.close();
        }catch(Exception e){
            e.printStackTrace();
        }
        try{
            PrintWriter writer = new PrintWriter("eventName.txt", "UTF-8");

            writer.print(eventName);
            writer.close();
        }catch(Exception e){
            e.printStackTrace();
        }
        try{
            PrintWriter writer = new PrintWriter("roundName.txt", "UTF-8");

            writer.print(roundName);
            writer.close();
        }catch(Exception e){
            e.printStackTrace();
        }
        try{
            PrintWriter writer = new PrintWriter("bestOf.txt", "UTF-8");

            writer.print(bestOf);
            writer.close();
        }catch(Exception e){
            e.printStackTrace();
        }
        try {
            
            exportGraphic(paint);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    

    public static void exportGraphic(Paint paint) {
        bi = new BufferedImage(1920, 1080, BufferedImage.TYPE_INT_ARGB);
        g = bi.createGraphics();
        paint.saveGraphics(g, bi, player1Score, player2Score, player1Name, player2Name,player1Sponsor,player2Sponsor,gameName,eventName,roundName,bestOf);
     
        //setLastModified();
    }


    private static void resetScores(JSpinner s, JSpinner s1){
        player1Score=0;
        s.setValue(player1Score);

        player2Score=0;
        s1.setValue(player2Score);
    }
    // resets all info
    private static void reset(JSpinner s, JSpinner s1,JTextField t, JTextField t1, JTextField ts1, JTextField ts2,JTextField ten,JTextField tgn,JTextField trn,JSpinner bo){
        player1Score=0;
        s.setValue(player1Score);
        player1Name = "Player 1";
        player1Sponsor="sponsor";
        

        t.setText(player1Name);
        ts1.setText(player1Sponsor);
        player2Score=0;
        s1.setValue(player2Score);
        player2Name = "Player 2";
        player2Sponsor="sponsor 2";

        t1.setText(player2Name);
        ts2.setText(player2Sponsor);

        eventName="event";
        gameName="game";
        roundName="round";
        bestOf=3;

        ten.setText(eventName);
        tgn.setText(gameName);
        trn.setText(roundName);
        bo.setValue(bestOf);

    }
}
